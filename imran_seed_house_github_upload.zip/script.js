// Imran Seed House — editable site interactions
document.addEventListener("DOMContentLoaded", function () {
  const modal = document.getElementById("orderModal");
  const form = document.getElementById("orderForm");
  const menuBtn = document.getElementById("menuBtn");
  const navLinks = document.getElementById("navLinks");
  const year = document.getElementById("year");
  let selectedOrderProduct = "Imran Seed House পণ্য";

  if (year) year.textContent = new Date().getFullYear();

  // Mobile navigation
  if (menuBtn && navLinks) {
    menuBtn.addEventListener("click", function () {
      navLinks.classList.toggle("open");
    });
    navLinks.querySelectorAll("a").forEach(function (link) {
      link.addEventListener("click", function () {
        navLinks.classList.remove("open");
      });
    });
  }

  function showOrderForm(button) {
    if (!modal || !form) {
      alert("অর্ডার ফর্মটি পাওয়া যাচ্ছে না। অনুগ্রহ করে পেজটি আবার লোড করুন।");
      return;
    }
    const productCard = button.closest(".product");
    const productTitle = productCard ? productCard.querySelector("h3") : null;
    selectedOrderProduct = productTitle
      ? productTitle.textContent.trim()
      : (button.getAttribute("data-product") || "Imran Seed House পণ্য");

    modal.classList.add("open");
    modal.setAttribute("aria-hidden", "false");
    document.body.style.overflow = "hidden";
    const firstInput = form.querySelector("input");
    if (firstInput) firstInput.focus();
  }

  function hideOrderForm() {
    if (!modal) return;
    modal.classList.remove("open");
    modal.setAttribute("aria-hidden", "true");
    document.body.style.overflow = "";
  }

  // Event delegation: supports every Buy Now button, including future product cards.
  document.addEventListener("click", function (event) {
    const buyButton = event.target.closest(".buy-now-btn");
    if (buyButton) {
      event.preventDefault();
      showOrderForm(buyButton);
      return;
    }
    if (event.target.closest(".order-close")) {
      hideOrderForm();
      return;
    }
    if (modal && event.target === modal) hideOrderForm();
  });

  document.addEventListener("keydown", function (event) {
    if (event.key === "Escape" && modal && modal.classList.contains("open")) {
      hideOrderForm();
    }
  });

  if (form) {
    form.addEventListener("submit", function (event) {
      event.preventDefault();
      if (!form.reportValidity()) return;

      const data = new FormData(form);
      const message = [
        "নতুন অর্ডার - Imran Seed House",
        "পণ্য: " + selectedOrderProduct,
        "ক্রেতার নাম: " + (data.get("name") || ""),
        "বিভাগ: " + (data.get("division") || ""),
        "জেলা: " + (data.get("district") || ""),
        "উপজেলা: " + (data.get("upazila") || ""),
        "ইউনিয়ন/পৌরসভা/সিটি করপোরেশন: " + (data.get("locality") || ""),
        "মোবাইল: " + (data.get("phone") || "")
      ].join("\n");

      // WhatsApp opens with the order details; the customer confirms by pressing Send there.
      const whatsappURL =
        "https://wa.me/8801615623057?text=" + encodeURIComponent(message);
      window.location.href = whatsappURL;
    });
  }
});
